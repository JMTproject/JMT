const {User, Recipe, Review, Ingredient, CookingTools, CookingStep} = require('../models')

const adminRp = (req, res) => {
    console.log('sample');
}

const adminUL = (req, res) => {
    console.log('sample');
}

module.exports = {adminRp, adminUL}