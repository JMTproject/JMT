const { rating, content, reviewImg, userId, recipeId } = require('../models');
